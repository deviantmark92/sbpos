<?php
/**
 * Application configuration.
 *
 * For real deployments, prefer environment variables over editing this file.
 * Any value below can be overridden by setting the matching environment var.
 */

return [
    // ---- Database (PostgreSQL) ----
    'db' => [
        'host'     => getenv('DB_HOST')     ?: '127.0.0.1',
        'port'     => getenv('DB_PORT')     ?: '5432',
        'name'     => getenv('DB_NAME')     ?: 'broasted_pos',
        'user'     => getenv('DB_USER')     ?: 'postgres',
        'password' => getenv('DB_PASSWORD') ?: 'postgres',
    ],

    // ---- App ----
    'app_name'        => 'Broasted Chicken POS',
    'currency_symbol' => '₱',          // Philippine Peso
    'currency_code'   => 'PHP',

    // Folder (relative to /public) where menu photos are stored
    'upload_dir'      => __DIR__ . '/../public/uploads',
    'upload_url'      => 'uploads',
    'max_upload_mb'   => 4,
];
