-- ============================================================
-- Broasted Chicken POS System - PostgreSQL Schema
-- ============================================================
-- Run with:  psql -U postgres -d broasted_pos -f sql/schema.sql
-- ============================================================

-- Clean slate (safe to re-run during development)
DROP TABLE IF EXISTS sale_items CASCADE;
DROP TABLE IF EXISTS sales CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- ------------------------------------------------------------
-- USERS  (Owner / Cashier accounts)
-- ------------------------------------------------------------
CREATE TABLE users (
    id            SERIAL PRIMARY KEY,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(120) NOT NULL,
    role          VARCHAR(20)  NOT NULL DEFAULT 'cashier'
                  CHECK (role IN ('owner', 'cashier')),
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- PRODUCTS  (Menu items + inventory)
-- ------------------------------------------------------------
CREATE TABLE products (
    id                  SERIAL PRIMARY KEY,
    name                VARCHAR(120)   NOT NULL,
    description         TEXT,
    category            VARCHAR(60)    NOT NULL DEFAULT 'General',
    price               NUMERIC(10,2)  NOT NULL DEFAULT 0 CHECK (price >= 0),
    photo_path          VARCHAR(255),
    stock_quantity      INTEGER        NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    low_stock_threshold INTEGER        NOT NULL DEFAULT 5  CHECK (low_stock_threshold >= 0),
    is_active           BOOLEAN        NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ------------------------------------------------------------
-- SALES  (Transaction header)
-- ------------------------------------------------------------
CREATE TABLE sales (
    id             SERIAL PRIMARY KEY,
    customer_name  VARCHAR(120) NOT NULL DEFAULT 'Walk-in',
    cashier_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    total_amount   NUMERIC(10,2) NOT NULL DEFAULT 0,
    payment_status VARCHAR(20)   NOT NULL DEFAULT 'pending'
                   CHECK (payment_status IN ('paid', 'pending')),
    note           TEXT,
    created_at     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    paid_at        TIMESTAMP
);

-- ------------------------------------------------------------
-- SALE_ITEMS  (Transaction line items)
-- ------------------------------------------------------------
CREATE TABLE sale_items (
    id          SERIAL PRIMARY KEY,
    sale_id     INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    product_id  INTEGER REFERENCES products(id) ON DELETE SET NULL,
    product_name VARCHAR(120) NOT NULL,         -- snapshot in case product is later removed
    quantity    INTEGER       NOT NULL CHECK (quantity > 0),
    unit_price  NUMERIC(10,2) NOT NULL,
    subtotal    NUMERIC(10,2) NOT NULL
);

-- ------------------------------------------------------------
-- Helpful indexes
-- ------------------------------------------------------------
CREATE INDEX idx_sales_created_at     ON sales(created_at);
CREATE INDEX idx_sales_payment_status ON sales(payment_status);
CREATE INDEX idx_sale_items_sale_id   ON sale_items(sale_id);
CREATE INDEX idx_products_active       ON products(is_active);
